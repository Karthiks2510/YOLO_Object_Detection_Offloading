package com.example.image_similarity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        Result aresult = this;
        Bundle extras = getIntent().getExtras();
        try {
            JSONObject jsonObject = new JSONObject(extras.getString("scores"));
            Toast.makeText(getApplicationContext(), jsonObject.getString("MSE"), Toast.LENGTH_SHORT).show();
            TextView mseView = findViewById(R.id.mseView);
            mseView.setText(jsonObject.getString("MSE"));
            TextView rmseView = findViewById(R.id.rmseView);
            rmseView.setText(jsonObject.getString("RMSE"));

            TextView psnrView = findViewById(R.id.psnrView);
            psnrView.setText(jsonObject.getString("PSNR"));
            TextView psnrbView = findViewById(R.id.psnrbView);
            psnrbView.setText(jsonObject.getString("PSNRB"));
            TextView ssimView = findViewById(R.id.ssimView);
            JSONArray ssim_arr = jsonObject.getJSONArray("SSIM");
            ssimView.setText(ssim_arr.getString(0) +"\n"+ssim_arr.getString(1));
            TextView ergasView = findViewById(R.id.ergasView);
            ergasView.setText(jsonObject.getString("ERGAS"));
            TextView uqiView = findViewById(R.id.uqiView);
            uqiView.setText(jsonObject.getString("UQI"));
            TextView raseView = findViewById(R.id.raseView);
            raseView.setText(jsonObject.getString("RASE"));
            TextView sccView = findViewById(R.id.sccView);
            sccView.setText(jsonObject.getString("SCC"));
            TextView samView = findViewById(R.id.samView);
            samView.setText(jsonObject.getString("SAM"));
            TextView vifpView = findViewById(R.id.vifpView);
            vifpView.setText(jsonObject.getString("VIFP"));

            
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        findViewById(R.id.Close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(aresult, MainActivity.class);
                startActivity(intent);
            }

        });
    }
}