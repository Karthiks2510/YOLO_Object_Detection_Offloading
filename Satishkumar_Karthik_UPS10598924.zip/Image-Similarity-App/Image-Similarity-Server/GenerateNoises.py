import os
import numpy as np
import cv2
from pathlib import Path

import skimage
from skimage.util import random_noise

file_name = "A01.jpg"
dir = "Generated-Images"
img_path = os.path.join(dir, file_name)


def generate_gaussian_noise(img):
    noises_list = ["gaussian", "localvar", "poisson", "salt" ,"pepper" , "s&p", "speckle"]
    for nos in noises_list:
        noise_img = random_noise(img, mode=nos)
        noise_img = np.array(255 * noise_img, dtype='uint8')
        save_path = os.path.join(dir, stem_file_name+"_"+nos+file_extn)
        cv2.imwrite(save_path, cv2.cvtColor(noise_img, cv2.COLOR_RGB2BGR))


img=skimage.io.imread(img_path)
stem_file_name = Path(file_name).stem
file_extn = Path(file_name).suffix
generate_gaussian_noise(img)