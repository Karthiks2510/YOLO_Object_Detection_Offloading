from typing import Union

from PIL import Image
from fastapi import FastAPI, File, UploadFile
import aiofiles
import os
import cv2
import time
import matplotlib.pyplot as plt
from sewar.full_ref import mse, rmse, rmse_sw, psnr, uqi, ssim, ergas, scc, rase, sam, msssim, vifp, psnrb
import math
app = FastAPI()

@app.get("/")
def read_root():
    return {"Hello": "World"}

@app.post("/PostImages")
async def post_images(img1: UploadFile = File(...), img2: UploadFile= File(...)):
    contents = await img1.read()
    img1_path = os.path.join("Uploaded-Images/", img1.filename)
    async with aiofiles.open(img1_path, 'wb') as f:
        await f.write(contents)
    contents = await img2.read()
    img2_path = os.path.join("Uploaded-Images/", img2.filename)
    async with aiofiles.open(img2_path, 'wb') as f:
        await f.write(contents)
        time.sleep(1)

    print(img1.filename, img2.filename)
    img1 = cv2.imread(img1_path)
    img2 = cv2.imread(img2_path)
    img1 = cv2.resize(img1, (256, 256), interpolation = cv2.INTER_LINEAR)
    img2 = cv2.resize(img2, (256, 256), interpolation = cv2.INTER_LINEAR)
    uqi_value = uqi(img1, img2)
    if math.isinf(uqi_value):
        uqi_value =  "NA"
    mse_value = mse(img1, img2)
    if math.isinf(mse_value):
        mse_value =  "NA"
    rmse_value = rmse(img1, img2)
    if math.isinf(rmse_value):
        rmse_value =  "NA"
    rmse_sw_value = rmse_sw(img1, img2)
    psnr_value = psnr(img1, img2)
    if math.isinf(psnr_value):
        psnr_value =  "NA"
    psnrb_value = psnrb(img1, img2)
    if math.isinf(psnrb_value):
        psnrb_value =  "NA"
    ssim_value = ssim(img1, img2)
    if math.isinf(ssim_value[0]):
        ssim_value[0] =  "NA"
    if math.isinf(ssim_value[1]):
        ssim_value[1] =  "NA"
    msssim_value = msssim(img1, img2)
    if math.isinf(msssim_value):
        msssim_value =  "NA"
    ergas_value = ergas(img1, img2)
    if math.isinf(ergas_value):
        ergas_value =  "NA"
    rase_value = rase(img1, img2)
    if math.isinf(rase_value):
        rase_value =  "NA"
    scc_value = scc(img1, img2)
    if math.isinf(scc_value):
        scc_value =  "NA"
    sam_value = sam(img1, img2)
    if math.isinf(sam_value):
        sam_value =  "NA"
    vifp_value = vifp(img1, img2)
    if math.isinf(vifp_value):
        vifp_value =  "NA"
    print(uqi_value, mse_value, rmse_value, psnr_value, psnrb_value, ssim_value, msssim_value, ergas_value, rase_value, scc_value, sam_value, vifp_value)
    print(111111111111111)
    return {"MSE": mse_value, "RMSE": rmse_value,   "PSNR": psnr_value, "PSNRB": psnrb_value, "SSIM": ssim_value, "ERGAS": ergas_value, "UQI": uqi_value, "RASE": rase_value, "SCC": scc_value, "SAM": sam_value, "VIFP": vifp_value}

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print("Finished")

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
