package com.example.image_similarity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.image_similarity.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    TextView textView1, textView2;
    ImageView imageView1, imageView2;
    ProgressBar pbar;
    private String filePath;
    Uri fileuri1 = null, fileuri2 =null;
    String fileName1 = null, fileName2 = null;
    public String ipAddr = "10.0.2.2:8000"; //"192.168.42.7";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView1 =  findViewById(R.id.textview1);
        textView2 =  findViewById(R.id.textview2);
        imageView1 =  findViewById(R.id.imageView1);
        imageView2 =  findViewById(R.id.imageView2);
        pbar =  findViewById(R.id.pbar);
        findViewById(R.id.buttonUploadImage1).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("On Click Called"+Manifest.permission.WRITE_EXTERNAL_STORAGE);
                if ((ContextCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(getApplicationContext(),
                                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)) {
                    System.out.println("If Part Called");
                    showFileChooser();
                } else {

                    System.out.println("Else Part Called");

                }


            }
        });
        findViewById(R.id.buttonUploadImage2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("On Click Called"+Manifest.permission.WRITE_EXTERNAL_STORAGE);
                if ((ContextCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) &&
                        (ContextCompat.checkSelfPermission(getApplicationContext(),
                                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)) {
                    System.out.println("If Part Called  2222222222222");
                    showFileChooser2();
                } else {

                    System.out.println("Else Part Called");

                }


            }
        });
        findViewById(R.id.buttonOffload).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadFile();
            }

        });
    }

    public static final int FILE_CHOOSER_1_RESULT_CODE = 901;
    public static final int FILE_CHOOSER_2_RESULT_CODE = 902;
    private void showFileChooser() {
        System.out.println("showFileChooser Called");
        Intent chooseFile = new Intent(Intent.ACTION_GET_CONTENT);
        chooseFile.setType("*/*");
        chooseFile = Intent.createChooser(chooseFile, "Choose a file");
        startActivityForResult(chooseFile, FILE_CHOOSER_1_RESULT_CODE);
    }
    private void showFileChooser2() {
        System.out.println("showFileChooser Called 222222222222222");
        Intent chooseFile = new Intent(Intent.ACTION_GET_CONTENT);
        chooseFile.setType("*/*");
        chooseFile = Intent.createChooser(chooseFile, "Choose a file");
        startActivityForResult(chooseFile, FILE_CHOOSER_2_RESULT_CODE);
    }
    @SuppressLint("Range")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println(requestCode +" "+ resultCode);
        switch (requestCode) {
            case FILE_CHOOSER_1_RESULT_CODE:
                if (resultCode == -1) {
                    Uri fileUri = data.getData();
                    this.fileuri1 = fileUri;
                    imageView1.setImageURI(fileUri);
                    filePath = fileUri.getPath();
                    this.textView1.setText(filePath);
                    Uri uri = data.getData();
                    String uriString = uri.toString();
                    File myFile = new File(uriString);
                    String path = myFile.getAbsolutePath();
                    String displayName = null;

                    if (uriString.startsWith("content://")) {
                        Cursor cursor = null;
                        try {
                            cursor = this.getContentResolver().query(uri, null, null, null, null);
                            if (cursor != null && cursor.moveToFirst()) {
                                displayName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                                System.out.println("uploadFile Before "+displayName);
                                this.fileName1 = displayName;
                                //uploadFile(displayName,uri);
                                System.out.println("uploadFile After XXXXX "+displayName);
                            }
                        } catch(Exception e) {
                            System.out.print("Exception XXXXX");
                            e.printStackTrace();
                        }
                        finally
                        {
                            cursor.close();
                        }
                    } else if (uriString.startsWith("file://")) {
                        displayName = myFile.getName();
                        Log.d("nameeeee>>>>  ",displayName);
                    }

                }
                break;
            case FILE_CHOOSER_2_RESULT_CODE:
                System.out.println("FILE_CHOOSER_2_RESULT_CODE222222222222");
                if (resultCode == -1) {
                    Uri fileUri = data.getData();
                    this.fileuri2 = fileUri;
                    imageView2.setImageURI(fileUri);
                    filePath = fileUri.getPath();
                    this.textView2.setText(filePath);
                    Uri uri = data.getData();
                    String uriString = uri.toString();
                    File myFile = new File(uriString);
                    String path = myFile.getAbsolutePath();
                    String displayName = null;

                    if (uriString.startsWith("content://")) {
                        Cursor cursor = null;
                        try {
                            cursor = this.getContentResolver().query(uri, null, null, null, null);
                            if (cursor != null && cursor.moveToFirst()) {
                                displayName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                                System.out.println("uploadFile Before "+displayName);
                                this.fileName2 = displayName;
                                //uploadFile(displayName,uri);
                                System.out.println("uploadFile After XXXXX "+displayName);
                            }
                        } catch(Exception e) {
                            System.out.print("Exception XXXXX");
                            e.printStackTrace();
                        }
                        finally
                        {
                            cursor.close();
                        }
                    } else if (uriString.startsWith("file://")) {
                        displayName = myFile.getName();
                        Log.d("nameeeee>>>>  ",displayName);
                    }

                }
                break;
        }


    }

    private RequestQueue rQueue;
    private void uploadFile(){
        System.out.println("uploadFile Inside");
        if (this.fileuri1 == null || this.fileuri2 == null){
            return;
        }
        InputStream iStream1 = null, iStream2 = null;
        try {

            iStream1 = getContentResolver().openInputStream(this.fileuri1);
            final byte[] inputData1 = getBytes(iStream1);
            System.out.println("uploadFile Inside 1 "+inputData1.length);

            iStream2 = getContentResolver().openInputStream(this.fileuri2);
            final byte[] inputData2 = getBytes(iStream2);
            System.out.println("uploadFile Inside 2 "+inputData2.length);
            pbar.setVisibility(View.VISIBLE);
            MainActivity amain =this;

            VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, "http://"+ipAddr+"/PostImages",
                    new Response.Listener<NetworkResponse>() {
                        @Override
                        public void onResponse(NetworkResponse response) {
                            System.out.println("Uploaded Successfully");
                            System.out.println(new String(response.data));
                            //rQueue.getCache().clear();
                            try {
                                JSONObject jsonObject = new JSONObject(new String(response.data));
                                Toast.makeText(getApplicationContext(), jsonObject.getString("PSNR"), Toast.LENGTH_SHORT).show();
                                pbar.setVisibility(View.INVISIBLE);
                                Intent intent = new Intent(amain, Result.class);
                                intent.putExtra("scores", new String(response.data));
                                startActivity(intent);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //error.printStackTrace();
                            //System.out.println("ERRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR");
                            //Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }) {

                /*
                 * If you want to add more parameters with the image
                 * you can do it here
                 * here we have only one parameter with the image
                 * which is tags
                 * */
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    //params.put("tags", "ccccc");  add string parameters
                    return params;
                }

                /*
                 *pass files using below method
                 * */
                @Override
                protected Map<String, DataPart> getByteData() {
                    System.out.println("getByteDatagetByteDatagetByteDatagetByteDatagetByteData");
                    Map<String, DataPart> params = new HashMap<>();

                    params.put("img1", new DataPart(fileName1 ,inputData1));
                    params.put("img2", new DataPart(fileName2 ,inputData2));
                    return params;
                }
            };
            Volley.newRequestQueue(this).add(volleyMultipartRequest);



        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }catch(Exception e){
            System.out.print("uploadFile Exception");
        }


    }

    public byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }
}